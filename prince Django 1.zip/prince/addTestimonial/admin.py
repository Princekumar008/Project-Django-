from django.contrib import admin

# Register your models here.

class addTestimonialAdmin(admin.ModelAdmin):
    list_display = ('name', 'role', 'message', 'photo')
    