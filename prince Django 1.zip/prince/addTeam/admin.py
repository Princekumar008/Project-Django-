from django.contrib import admin

# Register your models here.

class addTeamAdmin(admin.ModelAdmin):
    list_display = ('name', 'role', 'image', 'linkedin', 'twitter', 'facebook', 'instagram')