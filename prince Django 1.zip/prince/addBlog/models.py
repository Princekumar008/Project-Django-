from django.db import models
# from .models import addBlog

# Create your models here.

class addBlog(models.Model):
    image = models.ImageField(upload_to='blog_images/')
    title = models.CharField(max_length=200)
    description = models.TextField()
    date = models.DateField(auto_now_add=True)
    comments = models.IntegerField(default=0)
    teacher_name = models.CharField(max_length=100)
    teacher_image = models.ImageField(upload_to='teacher_images/')
    teacher_proffesion = models.CharField(max_length=100)
    