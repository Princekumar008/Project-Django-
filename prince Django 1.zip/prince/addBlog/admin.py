from django.contrib import admin

# Register your models here.

class addBlogAdmin(admin.ModelAdmin):
    list_display = ('title',  'image','date','description', 'comments','teacher_name', 'teacher_proffesion', 'teacher_image')
    