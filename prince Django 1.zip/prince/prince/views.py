from django.shortcuts import render
import requests
from addEvent.models import addEvent
from addTeam.models import addTeam
from addBlog.models import addBlog
from addTestimonial.models import addTestimonial
from home.models import Contact
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from django.template.loader import render_to_string

def home_page(request):
    Event = addEvent.objects.all()
    Team = addTeam.objects.all()
    Blog = addBlog.objects.all()
    Testimonial = addTestimonial.objects.all()

    return render(request, "index.html",{'event':Event, 'team':Team, 'blog':Blog, 'testimonial':Testimonial})

def about_page(request):
    return render(request, "about.html")

def blog_page(request):
    Blog = addBlog.objects.all()
    return render(request, "blog.html",{"blog":Blog})

def testimonial_page(request):
    Testimonial = addTestimonial.objects.all()
    return render(request, "testimonial.html", {"testimonial": Testimonial})

def contact_page(request):
    msg = ""
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        message = request.POST.get("message")
        contact = Contact(name=name, email=email, message=message)
        contact.save()
        
        reply_subject = f"Thanks for contacting us, {name}"
        plain_message = (
            f"Dear {name},\n\n"
            "Thank you for contacting us. We have received your message and will get back to you shortly.\n\n"
            f"{message}\n\n"
            "Best regards,\n"
            "Baby Care Support Team"
        )
        
        html_message = render_to_string("baby_email.html", {"name": name, "message": message})

        try:
            # Send confirmation to user
            send_mail(
                reply_subject,
                plain_message,
                settings.DEFAULT_FROM_MAIL,
                [email],
                fail_silently=False,
                html_message=html_message,
            )

            # Send copy to admin
            admin_subject = f"New Contact Form Submission from {name}"
            admin_message = (
                f"New message received from contact form:\n\n"
                f"Name: {name}\n"
                f"Email: {email}\n"
                f"Message:\n{message}\n"
            )
            send_mail(
                admin_subject,
                admin_message,
                settings.DEFAULT_FROM_MAIL,
                [settings.DEFAULT_FROM_MAIL],
                fail_silently=False,
            )
            msg = "Message Sent Successfully"
        except Exception as e:
            print(f"Error sending email: {e}")
            msg = f"Error sending email: {e}"
    return render(request, "contact.html", {"msg": msg})

def event_page(request):
    Event = addEvent.objects.all()
    return render(request, "event.html",{"event":Event})

def service_page(request):
    return render(request, "service.html")

def team_page(request):
    Team = addTeam.objects.all()
    return render(request, "team.html",{"team":Team})

def program_page(request):
    return render(request, "program.html")

def error_404_view(request):
    return render(request, "404.html")

def api_view(request):
    url ="https://jsonplaceholder.typicode.com/posts"
    data = []
    response = requests.get(url)
    data = response.json()
    return render(request, "api.html", {"data": data})